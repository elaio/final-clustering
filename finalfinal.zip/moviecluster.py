import numpy as np
import sys
import random


N = 6040
k = 3952


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def total_cost(C, ps1, ps2):
    return sum([cost(c, ps1, ps2) for c in C])


def cost(c, ps1, ps2):
    if len(c) == 1:
        m = c[0]
        return np.log(1 / ps1[m])

    s = 0
    for j, mj in enumerate(c):
        for t, mt in enumerate(c):
            if t < j:
                continue
            s += np.log(1 / ps2[j, t])

    return s / (len(c) - 1)


def probabilities(movies, ratings):
    m = len(movies)

    with open('movies per user.dat', 'r') as f:
        ns = np.loadtxt(f)

    with open('probabilities.dat', 'r') as f:
        ps1 = np.loadtxt(f)

    # joint probabilities only for the subset because of computing time
    ps2 = np.zeros((m, m))
    for j, mj in enumerate(movies):
        arrJ = np.where(ratings[:, j] > 0)[0]
        for t, mt in enumerate(movies):
            arrT = np.where(ratings[:, t] > 0)[0]
            arr = np.intersect1d(arrJ, arrT)
            ps2[j, t] = sum([ratings[i, j] * ratings[i, t] * 2 / (ns[i] * (ns[i] - 1)) for i in arr])
    ps2 = (ps2 + 2 / (k * (k - 1))) / (N + 1)

    return ps1, ps2


def correlations(movies, ps1, ps2):
    m = len(movies)

    cs = np.zeros((k, k))
    cs2 = np.zeros((m, m))
    for j, mj in enumerate(movies):
        for t, mt in enumerate(movies):
            cs[mj, mt] = (ps2[j, t] >= ps1[j] * ps1[t])
            cs2[j, t] = (ps2[j, t] >= ps1[j] * ps1[t])

    return cs


def ccpivot(movies, cs):
    if len(movies) == 0:
        return []

    i = random.choice(movies)
    c = [i]
    v2 = []

    for j in movies:
        if j == i:
            continue

        if cs[i, j]:
            c.append(j)
        else:
            v2.append(j)

    return [c] + ccpivot(v2, cs)


def after_pivot(C, ps1, ps2):
    after_C = C
    length = len(after_C)
    j = 0
    while j < 5:
        i = 0
        for c1 in after_C:
            cmin = -1
            min_cost = -1
            for c2 in after_C:
                if c1 == c2:
                    continue
                double_cost = cost(c1 + c2, ps1, ps2)
                single_cost = total_cost([c1, c2], ps1, ps2)
                if double_cost < single_cost:
                    if cmin == -1:
                        cmin = c2
                        min_cost = double_cost
                    elif double_cost < min_cost:
                        cmin = c2
                        min_cost = double_cost
            if cmin != -1:
                after_C.remove(c1)
                after_C.remove(cmin)
                after_C += [c1 + cmin]
            else:
                i += 1
            if i == length:
                # print('Ohhh')
                break
        j += 1

    return after_C


def main():
    file = sys.argv[3]
    alg = int(sys.argv[2])
    if alg != 1 and alg != 2:
        eprint('bad algorithm dawg')
        return

    # for i in range(20):
    #     movies = sorted(random.sample(range(3952), 100))
    #     with open(f'randomsubset{i+1}.txt', 'w') as f:
    #         np.savetxt(f, np.array(movies) + 1, fmt='%i')
    # exit()

    with open(file, 'r') as f:
        movies = list(np.loadtxt(f).astype(int) - 1)

    # movies50 = [21, 38, 69, 159, 205, 407, 714, 787, 857, 935, 1083, 1265, 1319, 1358, 1361, 1370, 1386, 1396, 1415, 1426, 1685, 1733, 1769, 1839, 1896, 1907, 1969, 2035, 2181, 2582, 2757, 2800, 2888, 3021, 3085, 3114, 3172, 3201, 3236, 3241, 3273, 3316, 3356, 3631, 3684, 3703, 3757, 3890, 3894, 3939]
    # movies100 = [7, 63, 91, 145, 163, 175, 252, 351, 406, 417, 422, 442, 509, 562, 586, 631, 658, 701, 788, 790, 817, 900, 1017, 1091, 1131, 1146, 1175, 1176, 1249, 1399, 1458, 1467, 1478, 1516, 1566, 1646, 1648, 1703, 1705, 1760, 1764, 1798, 1826, 1833, 1836, 1838, 1871, 1894, 1939, 1972, 1996, 2039, 2082, 2098, 2111, 2168, 2367, 2376, 2407, 2548, 2566, 2706, 2734, 2746, 2783, 2908, 2936, 2955, 2968, 2987, 3130, 3134, 3157, 3215, 3222, 3254, 3276, 3281, 3287, 3295, 3355, 3416, 3424, 3463, 3499, 3557, 3590, 3641, 3663, 3669, 3675, 3712, 3726, 3836, 3860, 3861, 3886, 3901, 3915, 3927]
    # movies170 = [66, 75, 102, 134, 144, 180, 215, 225, 236, 272, 288, 293, 322, 376, 394, 401, 408, 415, 423, 429, 461, 477, 490, 494, 503, 523, 537, 602, 681, 703, 715, 744, 781, 836, 885, 1001, 1003, 1020, 1079, 1089, 1153, 1165, 1193, 1229, 1253, 1276, 1333, 1374, 1379, 1381, 1438, 1446, 1448, 1460, 1515, 1523, 1531, 1551, 1561, 1567, 1587, 1613, 1629, 1635, 1644, 1662, 1673, 1732, 1827, 1838, 1846, 1882, 1912, 1928, 1963, 1970, 2013, 2029, 2060, 2088, 2090, 2110, 2111, 2139, 2147, 2148, 2161, 2175, 2193, 2201, 2217, 2248, 2289, 2306, 2313, 2314, 2329, 2374, 2377, 2399, 2420, 2423, 2427, 2511, 2523, 2580, 2601, 2617, 2647, 2658, 2664, 2696, 2782, 2804, 2849, 2852, 2859, 2870, 2894, 2906, 2923, 2926, 2960, 2965, 2967, 2989, 3003, 3006, 3016, 3017, 3018, 3027, 3108, 3139, 3151, 3164, 3169, 3181, 3202, 3224, 3225, 3291, 3315, 3323, 3325, 3335, 3353, 3410, 3440, 3466, 3549, 3552, 3580, 3583, 3633, 3665, 3666, 3678, 3710, 3716, 3738, 3767, 3770, 3775, 3814, 3833, 3887, 3915, 3928, 3937]
    # movies = sorted(random.sample(range(1, 3953), 170))
    # nah = [movies50, movies100, movies170]
    # for i in range(3):
    #     movies = nah[i]
    #     with open(f'subset{i + 1}.txt', 'w') as f:
    #         np.savetxt(f, np.array(movies) + 0, fmt='%i')
    # exit()

    for m in movies:
        if (type(m) != np.int64 and type(m) != np.int32 and type(m) != int) or m >= 3952 or m < 0:
            eprint('bad movies dawg')
            return
    with open('ratings.dat', 'r') as f:
        ratings = np.loadtxt(f, usecols=movies)
    to_remove = []
    for j, mj in enumerate(movies):
        num = sum(ratings[:, j])
        if num < 10:
            eprint(f'Movie {mj+1} ignored because it has only {num} ratings')
            to_remove += [mj]

    movies = [m for m in movies if m not in to_remove]
    with open('ratings.dat', 'r') as f:
        ratings = np.loadtxt(f, usecols=movies)

    ps1, ps2 = probabilities(movies, ratings)
    cs = correlations(movies, ps1, ps2)
    C = ccpivot(movies, cs)
    if alg == 2:
        tmp = C
        C = after_pivot(C, ps1, ps2)
    with open('titles.txt', 'r', encoding='latin-1') as f:
        titles = np.loadtxt(f, delimiter='\t', dtype=str)
    for c in C:
        for m in c:
            print(f'{m+1} "{titles[m]}"', end=', ')
        print()
    print(total_cost(C, ps1, ps2))
    # print(len(sorted([item for sublist in C for item in sublist])))
    # print(sorted([item for sublist in C for item in sublist]) == sorted([item for sublist in tmp for item in sublist]))


if __name__ == '__main__':
    main()
